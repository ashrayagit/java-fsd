package com.ecommerce.tests;

public class JUnitPlatform {

}
