package assessment;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.Scanner;
class Camera {
int id;
String brand; String model; int rentAmount; boolean available;
public Camera(int id, String brand, String model, int rentAmount, boolean available) {
this.id = id; this.brand = brand; this.model = model; this.rentAmount = rentAmount; this.available = available;
}
}
class Wallet { int balance;
public Wallet(int balance) { this.balance = balance;
}
public void addBalance(int amount) { balance += amount;
System.out.println("Your wallet balance updated successfully. Current balance: INR - " + balance);
}
public void viewBalance() {
System.out.println("Your current wallet balance is: INR - " + balance);
}
public boolean deductBalance(int amount) { if (balance >= amount) { balance -= amount; return true;
} else {
System.out.println("Transaction failed due to insufficient balance in the wallet. Please deposit the amount in your wallet:\n"); return false;
}
}
}
public class CameraRentalApp {
static ArrayList<Camera> cameraList = new ArrayList<>(); static Wallet wallet = new Wallet(30000);
public static void main(String[] args) {
Scanner scanner = new Scanner(System.in);
// Adding initial cameras to the list
cameraList.add(new Camera(1, "Samsung", "DS123", 500, true)); cameraList.add(new Camera(2, "Sony", "HD214", 500, true)); cameraList.add(new Camera(3, "Panasonic", "XC", 500, true));
cameraList.add(new Camera(4, "Canon", "XLR", 500, true)); cameraList.add(new Camera(5, "Fujitsu", "J5", 500, true)); cameraList.add(new Camera(6, "Sony", "HD226", 500, true)); cameraList.add(new Camera(7, "Samsung", "DS246", 500, false)); cameraList.add(new Camera(8, "LG", "L123", 500, true)); cameraList.add(new Camera(9, "Canon", "XPL",
500, true));
cameraList.add(new Camera(10, "Chroma", "CT", 500, true)); cameraList.add(new Camera(11, "Something", "Some", 200, false)); cameraList.add(new Camera(12, "Some", "Another", 100, false)); cameraList.add(new Camera(13, "Canon", "Digital", 123, true)); cameraList.add(new Camera(14, "NIKON ", "DSLR-D7500", 500, true));
cameraList.add(new Camera(15, "Sony", "DSLR12", 200, true)); cameraList.add(new Camera(17, "Samsung", "SM123", 500, false)); cameraList.add(new Camera(19, "SONY", "SONY1234", 123, true));cameraList.add(new Camera(17, "Samsung", "SM123", 500, false)); cameraList.add(new Camera(20, "Canon", "5050", 25000, true));cameraList.add(new Camera(21, "nikon", "2030", 500, true));
// Welcome screen
System.out.println("WELCOME TO CAMERA RENTAL APPLICATION:");
System.out.println("PLEASE LOGIN TO CONTINUE");
System.out.println("Enter The User Name:");
String userName = scanner.nextLine();
System.out.println("Enter The Password:");
String password = scanner.nextLine();
if (userName.equals("Ishwarya") && password.equals("12345")) 
{ System.out.println("Login Successful:\n");
}
while (true) {
    // Main menu
    System.out.println("OPTIONS TO BE DISPLAYED:\n");
    System.out.println("1. My Cameras");
    System.out.println("2. Rent a Camera");
    System.out.println("3. View All Cameras");
    System.out.println("4. My Wallet");
    System.out.println("5. Exit");
    int choice = scanner.nextInt();
    switch (choice) {
        case 1: myCameras(); break;
        case 2: rentCamera(); break;
        case 3: viewAllCameras(); break;
        case 4: myWallet(); break;
        case 5: System.exit(0);
        default: System.out.println("Invalid choice!");
        }
}
}
public static void myCameras() {
    Scanner scanner = new Scanner(System.in);
    while (true) {
        // My Cameras menu
        System.out.println("OPTIONS TO BE DISPLAYED\n");
        System.out.println("1. Add a Camera");
        System.out.println("2. Remove a Camera");
        System.out.println("3. View My Cameras");
        System.out.println("4. Go to Previous Menu");
        int choice = scanner.nextInt();
        switch (choice) {
            case 1: addCamera(); break;
            case 2:
                System.out.print("Enter the camera ID you want to remove: ");
                int removeId = scanner.nextInt();
                removeCamera(removeId);
                break;
            case 3: viewMyCameras(); break;
            case 4: return;
            default:
                System.out.println("Invalid choice!");
                break; // Add this line to break out of the loop after displaying the error message
        }
    }
}

public static void addCamera() {
    Scanner scanner = new Scanner(System.in);

    // Taking input for new camera details
    int id;
    while (true) {
        try {
            System.out.print("Enter camera ID: ");
            id = scanner.nextInt();
            scanner.nextLine();  // consume the newline character
            break;  // break out of the loop if input is valid
        } catch (InputMismatchException e) {
            System.out.println("Invalid input. Please enter a valid integer for camera ID.");
            scanner.nextLine();  // clear the invalid input
        }
    }

    System.out.print("Enter camera brand: ");
    String brand = scanner.nextLine();

    System.out.print("Enter camera model: ");
    String model = scanner.nextLine();

    System.out.print("Enter per-day rental amount: ");
    int rentAmount = scanner.nextInt();

    // Adding new camera to the list
    cameraList.add(new Camera(id, brand, model, rentAmount, true));
    System.out.println("Your Camera Has Been Successfully Added To The List!!");
}
public static boolean removeCamera(int id) {
    // Removing camera from the list using iterator
    Iterator<Camera> iterator = cameraList.iterator();
    while (iterator.hasNext()) {
        Camera camera = iterator.next();
        if (camera.id == id) {
            iterator.remove();  // Use iterator to remove the current element
            System.out.println("Camera successfully removed from the list:\n");

            // Set availability to true only if the camera is successfully removed
            camera.available = true;
            return true;
        }
    }
    System.out.println("Camera with ID " + id + " not found in the list:\n");
    return false;
}



public static void viewMyCameras() {
    // Displaying all cameras in the list 
    if (cameraList.isEmpty()) {
        System.out.println("No data present at this moment:\n");
    } else {
        for (Camera camera : cameraList) {
            System.out.println(camera.id + " " + camera.brand + " " + camera.model + " " + camera.rentAmount);
        }
    }
}
public static void rentCamera() {
    Scanner scanner = new Scanner(System.in);

    // Taking input for camera ID to be rented
    System.out.print("Enter the camera ID you want to rent:\n");
    int id = scanner.nextInt();

    // Search for the selected camera in the list
    Camera selectedCamera = null;
    for (Camera camera : cameraList) {
        if (camera.id == id) {
            selectedCamera = camera;
            break;
        }
    }

    if (selectedCamera != null) {
        // Checking if the user has sufficient balance in the wallet
        if (!wallet.deductBalance(selectedCamera.rentAmount)) {
            System.out.println("Transaction failed due to insufficient balance in the wallet. Please deposit the amount in your wallet:\n");
            return;
        }

        // Checking if the selected camera is available for rent
        if (!selectedCamera.available) {
            System.out.println("Transaction Failed Due To Camera Unavailability. Please choose another camera:\n");
            return;
        }

        // Renting the selected camera
        selectedCamera.available = false;
        System.out.println("Your transaction for Camera - " + selectedCamera.brand + " " + selectedCamera.model + " rented successfully.");

        // Update the wallet balance after successful rental
        System.out.println("Your wallet balance updated successfully. Current balance: INR - " + wallet.balance);
    } else {
        System.out.println("Camera with ID " + id + " not found in the list.");
    }
}


public static void viewAllCameras() {
    // Displaying all cameras in the list
    if (cameraList.isEmpty()) {
        System.out.println("No data present at this moment:\n");
    } else {
        for (Camera camera : cameraList) {
            System.out.println(camera.brand + " " + camera.model + " per-day rent amount: INR - :" + camera.rentAmount);
        }
    }
}

public static void myWallet() {
    Scanner scanner = new Scanner(System.in);
    while (true) {
        // My Wallet menu
        System.out.println("OPTIONS TO BE DISPLAYED");
        System.out.println("1. Add Money to Wallet:");
        System.out.println("2. View Wallet Balance:");
        System.out.println("3. Go to Previous Menu:");
        int choice = scanner.nextInt();
        switch (choice) {
            case 1:
                addMoneyToWallet();
                break;
            case 2:
                viewWalletBalance();
                break;
            case 3:
                return;
            default:
                System.out.println("Invalid choice!");
        }
    }
}
public static void addMoneyToWallet() {
    Scanner scanner = new Scanner(System.in);
    // Taking input for the amount to be added to the wallet
    while (true) {
        System.out.println("YOUR CURRENT WALLET BALANCE IS - INR " + wallet.balance);
        System.out.println("DO YOU WANT TO DEPOSIT MORE MONEY IN YOUR WALLET?");
        System.out.println("1. YES");
        System.out.println("2. NO");
        String choice = scanner.nextLine();
        if (choice.equals("1")) {
            System.out.print("Enter the amount you want to deposit: ");
            int amount = scanner.nextInt();
            scanner.nextLine(); // consume the newline character
            wallet.addBalance(amount);
        } else if (choice.equals("2")) {
            return;
        } else {
            System.out.println("Invalid option selected.");
        }
    }
}


public static void viewWalletBalance() {
    wallet.viewBalance();
}
}
