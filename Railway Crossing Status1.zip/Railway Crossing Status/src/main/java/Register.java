import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import Register.Member;
import Register.RegisterDao;
@WebServlet("/Register")
public class Register extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public Register() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Redirect to the registration page
        response.sendRedirect("Registration.jsp");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Retrieve user input from the form
        String uname = request.getParameter("uname");
        String password = request.getParameter("password");
        String email = request.getParameter("email");

        // Create a Member object
        Member user = new Member(uname, password, email);

        // Use RegisterDao to insert the user
        RegisterDao rDao = new RegisterDao();
        String result = rDao.insert(user);

        // Send the result as a response
        response.getWriter().print(result);
    }
}
