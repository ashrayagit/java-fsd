import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.GenericServlet;
import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/InterfaceDemo")
public class InterfaceDemo extends HttpServlet {

    @Override
    public void init() throws ServletException {
        System.out.println("Initialization complete");
    }

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        res.setContentType("text/html");
        PrintWriter pwriter = res.getWriter();
        pwriter.print("<html>");
        pwriter.print("<body>");
        pwriter.print("In the service() method<br>");
        pwriter.print("</body>");
        pwriter.print("</html>");
    }

    @Override
    public void destroy() {
        System.out.println("In destroy() method");
    }
    public ServletConfig getServletConfig(){
    	ServletConfig config=null;
        return config;
    }
    public String getServletInfo(){
        return "This is a sample servlet info";
    }
}

