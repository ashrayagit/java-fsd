package com.ecommerce;

public class PDescription {

}
