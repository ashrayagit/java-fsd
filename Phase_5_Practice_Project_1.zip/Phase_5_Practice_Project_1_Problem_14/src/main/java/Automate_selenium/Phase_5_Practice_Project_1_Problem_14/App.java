package Automate_selenium.Phase_5_Practice_Project_1_Problem_14;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
